/**
 * SEO Workspace — посередник для аудиту сторінки за URL (Cloudflare Worker).
 *
 * Що робить:
 *   GET /?url=https://example.com/page
 *   → завантажує сторінку як пошуковий бот (без виконання JavaScript),
 *     записує ланцюжок редиректів, заголовки X-Robots-Tag, HTML і robots.txt
 *   → повертає все одним JSON з CORS-заголовками для вашого сайту.
 *
 * Налаштування (Settings → Variables у Cloudflare):
 *   ALLOWED_ORIGINS = https://ваш-сайт.webflow.io,https://ваш-домен.com
 *   (через кому; якщо змінну не задано — дозволено будь-який сайт)
 */

const USER_AGENT =
  'Mozilla/5.0 (compatible; SEOWorkspaceAudit/1.0; +https://developers.cloudflare.com/workers/)';
const FETCH_TIMEOUT_MS = 15000;
const MAX_HTML_BYTES = 3_000_000;
const MAX_ROBOTS_BYTES = 500_000;
const MAX_REDIRECTS = 10;

export default {
  async fetch(request, env) {
    const cors = corsHeaders(request, env);

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors });
    }
    if (request.method !== 'GET') {
      return json({ error: 'Підтримується лише GET' }, 405, cors);
    }

    const target = new URL(request.url).searchParams.get('url');
    let startUrl;
    try {
      startUrl = new URL(target);
    } catch {
      return json({ error: 'Некоректний URL' }, 400, cors);
    }
    if (startUrl.protocol !== 'http:' && startUrl.protocol !== 'https:') {
      return json({ error: 'Підтримуються лише http і https' }, 400, cors);
    }
    if (isBlockedHost(startUrl.hostname)) {
      return json({ error: 'Ця адреса недоступна для перевірки' }, 400, cors);
    }

    const chain = [];
    let current = startUrl.toString();
    let response;

    try {
      for (let i = 0; i <= MAX_REDIRECTS; i++) {
        response = await fetchWithTimeout(current, {
          redirect: 'manual',
          headers: {
            'User-Agent': USER_AGENT,
            Accept: 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'uk,en;q=0.8,*;q=0.5',
          },
        });
        chain.push({ url: current, status: response.status });

        const location = response.headers.get('location');
        if (response.status >= 300 && response.status < 400 && location) {
          const next = new URL(location, current);
          if (isBlockedHost(next.hostname)) break;
          current = next.toString();
          continue;
        }
        break;
      }
    } catch (err) {
      return json(
        { error: `Не вдалося завантажити сторінку: ${err.name === 'AbortError' ? 'час очікування вичерпано' : err.message}`, chain },
        502,
        cors
      );
    }

    const contentType = response.headers.get('content-type') || '';
    const html = /html|xml/i.test(contentType) ? await readCapped(response, MAX_HTML_BYTES) : '';

    let robots = { status: 0, text: '' };
    try {
      const robotsUrl = new URL('/robots.txt', current).toString();
      const r = await fetchWithTimeout(robotsUrl, { headers: { 'User-Agent': USER_AGENT } });
      robots = { url: robotsUrl, status: r.status, text: r.ok ? await readCapped(r, MAX_ROBOTS_BYTES) : '' };
    } catch (err) {
      robots = { status: 0, text: '', error: err.message };
    }

    return json(
      {
        requestedUrl: startUrl.toString(),
        finalUrl: current,
        status: response.status,
        chain,
        headers: {
          contentType,
          xRobotsTag: response.headers.get('x-robots-tag'),
          lastModified: response.headers.get('last-modified'),
          cacheControl: response.headers.get('cache-control'),
          server: response.headers.get('server'),
        },
        html,
        htmlTruncated: html.length >= MAX_HTML_BYTES,
        robots,
        fetchedAt: new Date().toISOString(),
      },
      200,
      cors
    );
  },
};

function corsHeaders(request, env) {
  const origin = request.headers.get('Origin') || '';
  const allowed = (env.ALLOWED_ORIGINS || '*')
    .split(',')
    .map((s) => s.trim().replace(/\/$/, ''))
    .filter(Boolean);
  let allowOrigin = '*';
  if (!allowed.includes('*')) {
    allowOrigin = allowed.includes(origin) ? origin : allowed[0] || 'null';
  }
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400',
    Vary: 'Origin',
  };
}

function json(data, status, cors) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...cors },
  });
}

async function fetchWithTimeout(url, init) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function readCapped(response, maxBytes) {
  if (!response.body) return '';
  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let received = 0;
  let text = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    received += value.byteLength;
    if (received > maxBytes) {
      text += decoder.decode(value.subarray(0, value.byteLength - (received - maxBytes)), { stream: true });
      await reader.cancel();
      break;
    }
    text += decoder.decode(value, { stream: true });
  }
  return text + decoder.decode();
}

function isBlockedHost(hostname) {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal')) return true;
  if (h === '::1' || h.startsWith('fc') || h.startsWith('fd') || h.startsWith('fe80')) return h.includes(':');
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return false;
  const [a, b] = [Number(m[1]), Number(m[2])];
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127)
  );
}
